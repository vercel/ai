export type GatewayRealtimeModelId = string & {};
