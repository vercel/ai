export type GatewaySpeechModelId = string & {};
